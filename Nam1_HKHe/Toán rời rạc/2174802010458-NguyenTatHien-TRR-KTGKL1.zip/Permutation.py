from itertools import permutations
for i in permutations('ABC'):
    print(i)