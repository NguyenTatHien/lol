from itertools import combinations
for i in combinations('ABCDE', 3):
    print(i)