diemtrungbinh = float(input("Nhap diem trung binh: "))
diemrenluyen = float(input("Nhap diem ren luyen: "))
if not diemtrungbinh > 7 and diemrenluyen > 7:
    print("Khong duoc xet hoc bong")
else:
    print("Duoc xet hoc bong") 