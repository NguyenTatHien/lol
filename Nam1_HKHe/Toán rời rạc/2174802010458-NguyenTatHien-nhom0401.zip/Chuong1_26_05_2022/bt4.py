S = [x**2 + 4*x + 4 for x in range(20)]
print(S)