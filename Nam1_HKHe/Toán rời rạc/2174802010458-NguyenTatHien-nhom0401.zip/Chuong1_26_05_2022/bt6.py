#Cau a
A = 17
a1 = 10
a2 = 16
a3 = a1 ^ a2 ^ A
print("Đáp án a3: ",a3)

#Cau b
A = 17
a1 = 10
a3 = 11
a2 = a1 ^ A ^ a3
print("Đáp án a2: ",a2)

#Cau c
A = 17
a2 = 16
a3 = 11
a1 = A ^ a2 ^ a3
print("Đáp án a1: ",a1)