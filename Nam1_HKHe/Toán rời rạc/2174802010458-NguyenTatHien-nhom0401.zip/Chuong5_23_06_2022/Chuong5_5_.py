from pyswip import Prolog
tgtph = Prolog()
