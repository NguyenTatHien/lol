import itertools
for i in itertools.product('24', 'IT', repeat = 2): 
    print(i)