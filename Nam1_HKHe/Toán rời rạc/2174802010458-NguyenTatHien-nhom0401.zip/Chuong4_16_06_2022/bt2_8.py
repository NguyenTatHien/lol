from itertools import permutations
for i in permutations('ABC', 2):
    print(i)