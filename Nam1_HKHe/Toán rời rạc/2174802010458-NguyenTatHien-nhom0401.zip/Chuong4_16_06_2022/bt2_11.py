import itertools
for i in itertools.repeat('Red', 3): 
    print (i)