import itertools
for i in itertools.product('AB', 'C', 'DEF'): 
    print(i)