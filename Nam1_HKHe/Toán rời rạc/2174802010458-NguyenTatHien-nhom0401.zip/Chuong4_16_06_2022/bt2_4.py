import itertools
for i in itertools.product([1, 2],[6, 7, 8, 9]):
    print(i)