for i in ((i, j) for i in [1, 2] for j in [6,7,8,9]):
    print(i)