import itertools
for i in itertools.combinations('ABCDE', 3):
    print(i)