import itertools
for i in itertools.combinations_with_replacement('ABCDE', 3): 
    print (i) 