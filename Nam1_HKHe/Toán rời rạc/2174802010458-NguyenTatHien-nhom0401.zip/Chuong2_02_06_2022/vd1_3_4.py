day_so = range(2, 50)
print(map(lambda x: x * x, day_so))