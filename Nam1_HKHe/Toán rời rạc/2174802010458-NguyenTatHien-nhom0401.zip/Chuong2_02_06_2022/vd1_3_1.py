def f(x):
    return x**2
print(f(8))

g = lambda x: x**2
print(g(8))
g = lambda x: x**3