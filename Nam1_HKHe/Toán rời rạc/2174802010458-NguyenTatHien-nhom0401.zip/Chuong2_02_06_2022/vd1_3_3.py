day_so = range(2, 50)
print(filter(lambda x: x % 3 == 0, day_so))