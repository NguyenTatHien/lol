bongda_VN = ['Văn Lâm', 'Tiến Dũng', 'Anh Đức', 'Công Phượng'] 
for cau_thu in bongda_VN: 
    print ("Ten cau thu VietNam: ", cau_thu)
    
bongda_TG = ['Messi', 'Ronaldo', 'Thonglao', 'Mbappé']
for cau_thu in bongda_TG: 
    print ("Ten cau thu The gioi: ", cau_thu)

for bong_VN in bongda_VN:
    for bong_TG in bongda_TG: 
        print ("Khả năng tranh chấp quả bóng vàng giữa: ", bong_VN, " với ", bong_TG)
