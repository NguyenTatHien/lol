N = 4
for i1 in range(0, N): 
    for i2 in range(i1+1, N): 
        for i3 in range(i2+1, N): 
            print (i1, i2, i3)