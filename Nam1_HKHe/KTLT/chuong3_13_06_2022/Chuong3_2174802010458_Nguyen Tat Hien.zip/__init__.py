import hinhhoc.hinhchunhat, hinhhoc.hinhtron, hinhhoc.tamgiac
hinhhoc.hinhchunhat.cv_hcn()
hinhhoc.hinhchunhat.dt_hcn()
hinhhoc.hinhtron.chuvi_hinhtron()
hinhhoc.hinhtron.dientich_hinhtron()
hinhhoc.tamgiac.chuvi_tamgiac()
hinhhoc.tamgiac.dientich_tamgiac()