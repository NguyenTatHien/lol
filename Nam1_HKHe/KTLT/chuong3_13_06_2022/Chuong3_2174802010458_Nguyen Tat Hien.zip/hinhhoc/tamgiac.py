def dientich_tamgiac():
    day = float(input("Nhập vào độ dài đáy: "))
    h = float(input("Nhập vào chiều cao h: "))
    s = 1/2*day*h
    return print("Diện tích tam giác là: ",s)
def chuvi_tamgiac():
    a = float(input("Nhập vào cạnh a: "))
    b = float(input("Nhập vào cạnh b: "))
    c = float(input("Nhập vào cạnh c: "))
    p = a + b + c
    return print("Chu vi tam giác là: ",p)