def dientich_hinhtron():
    r = float(input("Nhập vào bán kính r: "))
    s = r * r * 3.14
    return print("Diện tích hình tròn là: ", s)
def chuvi_hinhtron():
    r = float(input("Nhập vào bán kính hình tròn: "))
    p = r * 2 * 3.14
    return print("Chu vi hình tròn là: ", p)