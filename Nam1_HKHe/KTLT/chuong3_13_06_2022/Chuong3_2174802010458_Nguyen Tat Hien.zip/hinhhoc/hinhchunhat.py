def dt_hcn():
    d = float(input("Nhập vào chiều dài: "))
    r = float(input("Nhập vào chiều rộng: "))
    s = d * r
    return print("Diện tích hcn là: ", s)
def cv_hcn():
    d = float(input("Nhập vào chiều dài: "))
    r = float(input("Nhập vào chiều rộng: "))
    p = (d + r)*2
    return print("Chu vi hcn là: ",p)