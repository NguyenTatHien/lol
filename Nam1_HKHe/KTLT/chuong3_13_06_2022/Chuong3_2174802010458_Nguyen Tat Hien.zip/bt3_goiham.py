import bt3
bt3.dientich_hcn()
bt3.chuvi_hcn()
bt3.dientich_tamgiac()
bt3.chuvi_tamgiac()
bt3.dientich_hcn()
bt3.chuvi_hinhtron()