import bt2
bt2.add()
bt2.sub()
bt2.multiple()
bt2.divide()
bt2.can_bac_hai()