def show_id():
    id = int(input("Nhập mssv: "))
    return id
def show_name():
    name = input("Nhập Họ & Tên: ")
    return name
def show_class():
    cl = input("Nhập vào lớp: ")
    return cl
def show_email():
    email = input("Nhập vào email: ")
    return email    