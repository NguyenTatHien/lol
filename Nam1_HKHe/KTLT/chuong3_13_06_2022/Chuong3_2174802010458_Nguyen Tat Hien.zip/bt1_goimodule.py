import bt1
bt1.show_id()
bt1.show_name()
bt1.show_class()
bt1.show_email()