def cong(x,y):
    return print(x+y)
def mu(x,y):
    return print(x**y)
def bac3(x):
    return print(x**1/3) 