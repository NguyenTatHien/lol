def chuvi_tamgiac(a,b,c):
    return print(a+b+c)
def dientich_tamgiac(a, h):
    return print((1/2)*a*h)
