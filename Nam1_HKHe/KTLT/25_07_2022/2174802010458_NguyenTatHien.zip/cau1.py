def thongtin(CMND, hovaten, diachi, email):
    print("CMND: ", CMND)
    print("Họ và tên: ", hovaten)
    print("Địa chỉ: ", diachi)
    print("Email: ", email)

thongtin(int(input("Nhập vào cmnd: ")),input("Nhập vào họ và tên: "),input("Nhập vào địa chỉ: "),input("Nhập vào email: "))