f = open("C:\\CODE\\KTLT\\ghifile_tenSV.txt", "a", encoding="utf-8")
print(f.write(input("Nhập vào nội dung cần thêm: ")))