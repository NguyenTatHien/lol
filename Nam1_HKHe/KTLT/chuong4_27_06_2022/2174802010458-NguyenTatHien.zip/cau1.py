f = open("C:\\CODE\\KTLT\\docfile.txt", "r", encoding="utf-8")
print(f.read())