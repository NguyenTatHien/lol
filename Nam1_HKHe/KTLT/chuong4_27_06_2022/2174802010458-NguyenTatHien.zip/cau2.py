f = open("C:\\CODE\\KTLT\\ghifile_tenSV.txt", "w", encoding="utf-8")
print(f.write(input("Nhập vào nội dung: ")))